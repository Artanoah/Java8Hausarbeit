package benchmarkTool.benchmark;

public class Constants {
	public static final String sgbWords = "sgb-words.txt";
}
