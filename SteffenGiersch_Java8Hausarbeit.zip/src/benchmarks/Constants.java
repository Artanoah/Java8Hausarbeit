package benchmarks;

/**
 * Klasse zum Halten der Konstanten fuer Benchmarks.
 * 
 * @author Steffen Giersch
 */
public class Constants {
	public static final String SGBWORDS = "sgb-words.txt";
}
